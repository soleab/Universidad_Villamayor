import connexion
import smtplib
from swagger_server.models.correo import Correo
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime

emails = {}

def obtener_correos(tamanoPagina=None, numeroPaginas=None):
    """
    Obtiene usuarios
    Obtiene un listado de usuarios del sistema.
    :param tamanoPagina: Número de personas devueltas
    :type tamanoPagina: int
    :param numeroPaginas: Número de páginas devueltas
    :type numeroPaginas: int

    :rtype: List[Usuario]
    """

    return [user for _, user in emails.items()]

def crear_correo(correo):
    """
    Crea un usuario
    Añade un usuario a la lista de usuarios.
    :param usuario: El usuario que se va a añadir.
    :type usuario: dict | bytes

    :rtype: None
    """

    if connexion.request.is_json:
        print("Convirtiendo usuario")
        correo = Correo.from_dict(connexion.request.get_json())
    #print(usuario.first_name)
    #print(dir(usuario))
    #TODO Check the username does not exist.
    emails[correo.email] = correo
    return 'Usuario {} creado'.format(correo.email)

def enviar_correo(correo):
    """
    Envia el mail del recordatorio
    :param email: el email de destino
    :type string
    """
    if connexion.request.is_json:
        print("Convirtiendo usuario")
        correo = Correo.from_dict(connexion.request.get_json())

    from_addr    = 'universidadnoreply@gmail.com'
    to_addr_list = [correo.email]
    subject      = 'Recordatorio de pago'
    message      = 'Hola muy buenas, le recordamos que debe de pagar'
    login        = 'universidadnoreply'
    password     = 'ingsoftware'
    smtpserver='smtp.gmail.com:587'


    header = 'Subject: %s\n\n' % subject
    message = header + message

    server = smtplib.SMTP(smtpserver)
    server.starttls()
    server.login(login,password)
    server.sendmail(from_addr, to_addr_list, message)
    server.quit()

    return 'Email enviado a {}'.format(correo.email)
