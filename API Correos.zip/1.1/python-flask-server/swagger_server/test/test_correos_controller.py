# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.correo import Correo
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestCorreosController(BaseTestCase):
    """ CorreosController integration test stubs """

    def test_crear_correo(self):
        """
        Test case for crear_correo

        Crea un usuario con correo
        """
        correo = Correo()
        response = self.client.open('/miAplicacion/correo',
                                    method='POST',
                                    data=json.dumps(correo),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_enviar_correo(self):
        """
        Test case for enviar_correo

        Envia un mail
        """
        correo = Correo()
        response = self.client.open('/miAplicacion/email',
                                    method='PUT',
                                    data=json.dumps(correo),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_obtener_correos(self):
        """
        Test case for obtener_correos

        Obtiene correos
        """
        query_string = [('tamanoPagina', 56),
                        ('numeroPaginas', 56)]
        response = self.client.open('/miAplicacion/correos',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
