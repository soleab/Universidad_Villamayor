# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.aulas import Aulas
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestAulasController(BaseTestCase):
    """ AulasController integration test stubs """

    def test_info_aula(self):
        """
        Test case for info_aula

        Obtener la información de un aula
        """
        query_string = [('id', 'id_example')]
        response = self.client.open('/Aulas',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_info_aulas(self):
        """
        Test case for info_aulas

        Obtener las aulas de un centro
        """
        query_string = [('Centro', 'Centro_example')]
        response = self.client.open('/Aulas/Centro',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_modificar(self):
        """
        Test case for modificar

        Modificar aulas
        """
        modificarAulas = Aulas()
        response = self.client.open('/Aulas',
                                    method='PUT',
                                    data=json.dumps(modificarAulas),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
