import connexion
from swagger_server.models.aulas import Aulas
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime

import psycopg2


def info_aula(id):
    """
    Obtener la información de un aula
    
    :param id: información del aula buscada por su nombre
    :type id: str

    :rtype: None
    """
    conn = psycopg2.connect("dbname=aulasuv user=profesor password=profesor host=localhost")
    #creamos la conexión con la bdd
    cur = conn.cursor()
    cur.execute("SELECT * FROM aulas WHERE id = '"+id+"'")
    #ejecutamos la consulta
    rows = cur.fetchall()

    return rows


def info_aulas(Centro):
    """
    Obtener las aulas de un centro
    
    :param Centro: nombre del centro
    :type Centro: str

    :rtype: None
    """
    conn = psycopg2.connect("dbname=aulasuv user=profesor password=profesor host=localhost")
    cur = conn.cursor()
    cur.execute("SELECT * FROM aulas WHERE centro = '"+Centro+"'")
    rows = cur.fetchall()
    
    return rows


def modificar(modificarAulas):
    """
    Modificar aulas
    
    :param modificarAulas: aula a modificar
    :type modificarAulas: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        modificarAulas = Aulas.from_dict(connexion.request.get_json())

        conn = psycopg2.connect("dbname=aulasuv user=profesor password=profesor host=localhost")
        cur = conn.cursor()
        cur.execute("UPDATE aulas set tipo = '"+str(modificarAulas.Tipo)+"', precio = "+int(modificarAulas.Precio)+", capacidad = "+int(modificarAulas.Capacidad)+" WHERE id = '"+str(modificarAulas.Id)+"';")
    return 'Actualizado con éxito'
