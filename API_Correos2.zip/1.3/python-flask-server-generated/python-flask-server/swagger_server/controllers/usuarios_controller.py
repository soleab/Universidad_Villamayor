import connexion
from swagger_server.models.usuario import Usuario
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime
import smtplib

emails = {}


def crear_usuario(usuario):
    """
    Crea un usuario con correo
    Añade un correo a la lista de correos.
    :param usuario: El usuario que se va a añadir.
    :type usuario: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        usuario = Usuario.from_dict(connexion.request.get_json())

    """Si al crear usuario dias es 15 o 30 ejecutar la funcion enviar_correo(correo)"""

    #Añadir usuario a base de datos
    #email = usuario.get("email")
    #nombre = usuario.get("username")
    #dia = usuario.get("dia")
    #consulta ='insert into public."Usuarios" values(\'%s\',\'%s\',\'%s\')' % (nombre,email, dia)
    #resultado = conn.query(consulta)

    emails[usuario.user] = usuario

    if usuario.dias==15 or usuario.dias==30:
        enviar_correo(usuario)

    return 'Usuario {} creado'.format(usuario.user)

def eliminar_usuario(user):
    """
    Borrar usuario
    Borrar usuario
    :param usuario: El usuario que se va a eliminar.
    :type usuario: dict | bytes

    :rtype: None
    """
    #if connexion.request.is_json:
    #    usuario = Usuario.from_dict(connexion.request.get_json())

    del emails[user]

    #Eliminar en Base de datos
    # consulta ='delete from public."Usuarios" where public."Usuarios"."LoginID" = \'%s\'' % usuario
    #resultado = conn.query(consulta)"""

    return 'Usuario eliminado correctamente'

def enviar_correo(usuario):
    """
    Envia un mail
    Envía un email con el recordatorio del pago.
    :param usuario: El usuario al que se va a enviar el correo.
    :type usuario: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        usuario = Usuario.from_dict(connexion.request.get_json())

    from_addr    = 'universidadnoreply@gmail.com'
    to_addr_list = [usuario.email]
    subject      = 'Recordatorio de pago'
    message      = 'Hola muy buenas, le recordamos que debe de pagar'
    login        = 'universidadnoreply'
    password     = 'ingsoftware'
    smtpserver='smtp.gmail.com:587'


    header = 'Subject: %s\n\n' % subject
    message = header + message

    server = smtplib.SMTP(smtpserver)
    server.starttls()
    server.login(login,password)
    server.sendmail(from_addr, to_addr_list, message)
    server.quit()

    return 'Email enviado a {}'.format(usuario.email)

def obtener_usuarios():

    #consulta= 'Select * from public."Usuarios"'
    #resultado= conn.query(consulta)
    #return json.dumps(resultado.getresult())

    return [user for _, user in emails.items()]

def obtener_usuario(user):

    #Obtener usuario en base de datos
    #consulta = 'select public."Usuarios"."LoginID",public."Usuarios"."email"  from public."Usuarios" where public."Usuarios"."LoginID" = \'%s\'' % user
    #resultado = conn.query(consulta)
    #return json.dumps(resultado.getresult())

    return emails[user]
