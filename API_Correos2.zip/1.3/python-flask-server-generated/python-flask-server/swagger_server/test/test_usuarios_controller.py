# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.usuario import Usuario
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestUsuariosController(BaseTestCase):
    """ UsuariosController integration test stubs """

    def test_crear_usuario(self):
        """
        Test case for crear_usuario

        Crea un usuario con correo
        """
        usuario = Usuario()
        response = self.client.open('/miAplicacion/usuario',
                                    method='POST',
                                    data=json.dumps(usuario),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_eliminar_usuario(self):
        """
        Test case for eliminar_usuario

        Borrar usuario
        """
        response = self.client.open('/miAplicacion/usuario/{user}'.format(user='user_example'),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_enviar_correo(self):
        """
        Test case for enviar_correo

        Envia un mail
        """
        usuario = Usuario()
        response = self.client.open('/miAplicacion/sendEmail',
                                    method='PUT',
                                    data=json.dumps(usuario),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_obtener_usuario(self):
        """
        Test case for obtener_usuario

        Obtiene usuario por nombre de usuario
        """
        response = self.client.open('/miAplicacion/usuario/{user}'.format(user='user_example'),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_obtener_usuarios(self):
        """
        Test case for obtener_usuarios

        Obtiene usuarios
        """
        response = self.client.open('/miAplicacion/usuario',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
